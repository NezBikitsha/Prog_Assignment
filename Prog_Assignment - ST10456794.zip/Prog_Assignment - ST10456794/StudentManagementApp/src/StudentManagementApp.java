import javax.swing.*;
import java.util.ArrayList;

class Student {
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;

    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    @Override
    public String toString() {
        return "ID: " + id + "\nName: " + name + "\nAge: " + age + "\nEmail: " + email + "\nCourse: " + course;
    }
}

public class StudentManagementApp {
    private static ArrayList<Student> students = new ArrayList<>();

    public static void main(String[] args) {
        while (true) {
            String input = JOptionPane.showInputDialog(
                    "STUDENT MANAGEMENT APPLICATION\n" +
                            "Enter (1) to launch menu or any other key to exit"
            );

            if (!"1".equals(input)) {
                break;
            }

            showMenu();
        }
    }

    private static void showMenu() {
        String[] options = {
                "1. Capture a new student.",
                "2. Search for a student.",
                "3. Delete a student.",
                "4. Print student report.",
                "5. Exit Application."
        };

        String choice = (String) JOptionPane.showInputDialog(
                null,
                "Please select one of the following menu items:",
                "Menu",
                JOptionPane.PLAIN_MESSAGE,
                null,
                options,
                options[0]
        );

        if (choice == null) return; // If user cancels

        switch (choice.charAt(0)) {
            case '1' -> captureStudent();
            case '2' -> searchStudent();
            case '3' -> deleteStudent();
            case '4' -> printStudentReport();
            case '5' -> System.exit(0);
            default -> JOptionPane.showMessageDialog(null, "Invalid option, please try again.");
        }
    }

    private static void captureStudent() {
        String id = JOptionPane.showInputDialog("Enter the student id:");
        String name = JOptionPane.showInputDialog("Enter the student name:");

        // Validate age input
        int age = 0;
        boolean validAge = false;
        while (!validAge) {
            try {
                String ageInput = JOptionPane.showInputDialog("Enter the student age:");
                age = Integer.parseInt(ageInput);
                if (age < 16) {
                    JOptionPane.showMessageDialog(null, "You have entered an incorrect student age!!!\nPlease re-enter the student age >>");
                } else {
                    validAge = true;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "You have entered an incorrect student age!!!\nPlease re-enter the student age >>");
            }
        }

        String email = JOptionPane.showInputDialog("Enter the student email:");
        String course = JOptionPane.showInputDialog("Enter the student course:");

        Student student = new Student(id, name, age, email, course);
        students.add(student);

        JOptionPane.showMessageDialog(null, "Student captured successfully.");
    }


    private static void searchStudent() {
        String id = JOptionPane.showInputDialog("Enter the student id to search:");
        boolean studentFound = false;

        for (Student student : students) {
            if (student.getId().equals(id)) {
                String studentDetails =
                        "STUDENT ID: " + student.getId() + "\n" +
                                "STUDENT NAME: " + student.getName() + "\n" +
                                "STUDENT AGE: " + student.getAge() + "\n" +
                                "STUDENT EMAIL: " + student.getEmail() + "\n" +
                                "STUDENT COURSE: " + student.getCourse();
                JOptionPane.showMessageDialog(null, studentDetails);
                studentFound = true;
                break;
            }
        }

        if (!studentFound) {
            JOptionPane.showMessageDialog(null,
                    "Student with Student ID: " + id + " was not found!");

        }
    }


    private static void deleteStudent() {
        String id = JOptionPane.showInputDialog("Enter the student id to delete:");
        boolean studentFound = false;

        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId().equals(id)) {
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Are you sure you want to delete student " + id + " from the system?",
                        "Delete Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    students.remove(i);
                    JOptionPane.showMessageDialog(null, "Student with Student ID: " + id + " WAS deleted!");

                } else {
                    JOptionPane.showMessageDialog(null,
                            "Deletion canceled.");
                }
                studentFound = true;
                break;
            }
        }

        if (!studentFound) {
            JOptionPane.showMessageDialog(null,
                    "Student with Student ID: " + id + " was not found!");
        }
    }


    private static void printStudentReport() {
        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No students available to display.");
            return;
        }

        StringBuilder report = new StringBuilder();
        int studentNumber = 1;

        for (Student student : students) {
            report.append("STUDENT ").append(studentNumber).append("\n")
                    .append("STUDENT ID: ").append(student.getId()).append("\n")
                    .append("STUDENT NAME: ").append(student.getName()).append("\n")
                    .append("STUDENT AGE: ").append(student.getAge()).append("\n")
                    .append("STUDENT EMAIL: ").append(student.getEmail()).append("\n")
                    .append("STUDENT COURSE: ").append(student.getCourse()).append("\n");
            studentNumber++;
        }

        JOptionPane.showMessageDialog(null, report.toString());
    }
    private static void exitApplication() {
        int confirm = JOptionPane.showConfirmDialog(null,
                "Are you sure you want to exit the application?",
                "Exit Confirmation",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "Exiting application. Goodbye!");
            System.exit(0);
        }
    }
}
