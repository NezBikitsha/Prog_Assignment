class Person {
    protected String name;
    protected int id;

    public Person(String name, int id) {
        this.name = name;
        this.id = id;
    }

    // Getter methods for name and id
    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }
}

// Subject.java
class Subject {
    private String subjectName;
    private int marks;

    public Subject(String subjectName, int marks) {
        this.subjectName = subjectName;
        this.marks = marks;
    }

    // Getter methods for subject name and marks
    public String getSubjectName() {
        return subjectName;
    }

    public int getMarks() {
        return marks;
    }
}


class Student extends Person {
    private Subject[] subjects;
    private int subjectCount;

    public Student(String name, int id, int numOfSubjects) {
        super(name, id);
        subjects = new Subject[numOfSubjects];
        subjectCount = 0;
    }

    // Method to add subjects
    public void addSubject(String subjectName, int marks) {
        if (subjectCount < subjects.length) {
            subjects[subjectCount] = new Subject(subjectName, marks);
            subjectCount++;
        } else {
            System.out.println("Cannot add more subjects.");
        }
    }

    // Method to calculate total marks
    public int getTotalMarks() {
        int total = 0;
        for (Subject subject : subjects) {
            total += subject.getMarks();
        }
        return total;
    }

    // Method to calculate average marks
    public double getAverageMarks() {
        return getTotalMarks() / (double) subjectCount;
    }

    // Method to determine the grade based on average marks
    public String getGrade() {
        double average = getAverageMarks();
        if (average >= 85) {
            return "A";
        } else if (average >= 70) {
            return "B";
        } else if (average >= 50) {
            return "C";
        } else {
            return "D";
        }
    }

    // Method to display student report
    public void displayReport() {
        System.out.println("Student Name: " + getName());
        System.out.println("Student ID: " + getId());
        for (Subject subject : subjects) {
            System.out.println("Subject: " + subject.getSubjectName() + " | Marks: " + subject.getMarks());
        }
        System.out.println("Total Marks: " + getTotalMarks());
        System.out.println("Average Marks: " + getAverageMarks());
        System.out.println("Grade: " + getGrade());
    }
}


public class Main {
    public static void main(String[] args) {
        // Create a new student with 3 subjects
        Student student = new Student("Alice", 101, 3);

        // Add subjects and their marks
        student.addSubject("Math", 80);
        student.addSubject("Science", 90);
        student.addSubject("History", 75);

        // Display the student report
        student.displayReport();
    }
}
